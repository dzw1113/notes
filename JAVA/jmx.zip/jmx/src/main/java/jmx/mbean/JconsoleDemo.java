package jmx.mbean;

import java.lang.management.ManagementFactory;

import javax.management.MBeanServer;
import javax.management.ObjectName;
import javax.management.modelmbean.DescriptorSupport;
import javax.management.modelmbean.ModelMBeanAttributeInfo;
import javax.management.modelmbean.ModelMBeanInfo;
import javax.management.modelmbean.ModelMBeanInfoSupport;
import javax.management.modelmbean.ModelMBeanOperationInfo;
import javax.management.modelmbean.RequiredModelMBean;
/** 
 *  JMX DEMO（jconsole）
 *  使用 Model MBean 的过程也是下面几步：
 *  1、创建一个 MBServer：mBeanServe
 *  2、获得管理资源用的 MBean：serverBean
 *  3、给这个 MBean 一个 ObjectName：serverMBeanName
 *  4、将 serverBean 以 serverMBeanName 注册到 mBeanServer 上去
 */  
public class JconsoleDemo {  
  
    /** 
     * 
     * @param args 
     * @throws Exception 
     */  
    public static void main(String[] args) throws Exception {  
        //获取Mean的平台服务  
        MBeanServer mbs = ManagementFactory.getPlatformMBeanServer();  
        // 对即将被注册的MBean 构造一个ObjectName  
        ObjectName objectName = new ObjectName("com.cathy.demo.jmx:type=Hi");  
        // 创建一个Mbean  
        RequiredModelMBean mbean = new RequiredModelMBean();  
        HiMbeanImpl hiMbean = new HiMbeanImpl();  
        mbean.setManagedResource(hiMbean, "objectReference");  
  
        ModelMBeanAttributeInfo name = new ModelMBeanAttributeInfo("name", "java.lang.String",  
            "userName", true, true, false, new DescriptorSupport(new String[] { "name=name",  
                    "descriptorType=attribute", "getMethod=getName", "setMethod=setName" }));  
  
        ModelMBeanOperationInfo sayHello = new ModelMBeanOperationInfo("say Hello", hiMbean  
            .getClass().getMethod("sayHello"));  
        // 创建一个ModelMBeanOperationInfo  
        ModelMBeanOperationInfo getName = new ModelMBeanOperationInfo("get userName", hiMbean  
            .getClass().getMethod("getName"));  
  
        // 使用ModelMbeanAttributeInfo和ModelMbeanOperationInfo构建一个ModelMBeanInfo对象  
        ModelMBeanInfo mbeanInfo = new ModelMBeanInfoSupport("HiMbean", "Test",  
            new ModelMBeanAttributeInfo[] { name }, null, new ModelMBeanOperationInfo[] { sayHello,  
                    getName }, null);  
        // 向ModelMBean 设置ModelMBeanInfo  
        mbean.setModelMBeanInfo(mbeanInfo);  
  
        // 将Mbean 注册到MBeanServer  
        mbs.registerMBean(mbean, objectName);  
        // 一直等待  
        System.out.println("Waiting forever...");  
        Thread.sleep(Long.MAX_VALUE);  
  
    }  
}
