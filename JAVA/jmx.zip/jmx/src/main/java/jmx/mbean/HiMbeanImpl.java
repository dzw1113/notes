package jmx.mbean;

/**
 * 简单实现类
 * 
 */
public class HiMbeanImpl implements HiMBean {

	private final String name = "Reginald";
	private int cacheSize = DEFAULT_CACHE_SIZE;
	private static final int DEFAULT_CACHE_SIZE = 200;

	/**
	 * @see jmx.mbean.cathy.demo.jmx.notifications.HiMBean#sayHello()
	 */
	public void sayHello() {
		System.out.println("Hello," + getName());
	}

	/**
	 * @see jmx.mbean.cathy.demo.jmx.notifications.HiMBean#add(int, int)
	 */
	public int add(int x, int y) {
		return x + y;
	}

	/**
	 * @see jmx.mbean.cathy.demo.jmx.notifications.HiMBean#getName()
	 */
	public String getName() {
		return name;
	}

	/**
	 * @see jmx.mbean.cathy.demo.jmx.notifications.HiMBean#getCacheSize()
	 */
	public int getCacheSize() {
		return cacheSize;
	}

	/**
	 * @see jmx.mbean.cathy.demo.jmx.notifications.HiMBean#setCacheSize(int)
	 */
	public void setCacheSize(int size) {
		cacheSize = size;
	}

}
