package jmx.mxbean;

/**
 * MXBean接口，定义两个操作
 */
public interface QueueSamplerMXBean {

	public QueueSample getQueueSample();

	public void clearQueue();
}
