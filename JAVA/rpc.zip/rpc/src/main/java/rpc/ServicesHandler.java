package rpc;

public interface ServicesHandler {
	 public String execute(String str);
}
