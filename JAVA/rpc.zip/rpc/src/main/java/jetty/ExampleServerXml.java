package jetty;

import org.eclipse.jetty.util.resource.Resource;
import org.eclipse.jetty.xml.XmlConfiguration;

/**
 * XML启动jetty
 * https://github.com/eclipse/jetty.project/blob/jetty-9.4.x/examples/embedded/src/main/java/org/eclipse/jetty/embedded/ExampleServerXml.java
 */
public class ExampleServerXml {
	public static void main(String[] args) throws Exception {
		// Find Jetty XML (in classpath) that configures and starts Server.
		Resource serverXml = Resource.newSystemResource("exampleserver.xml");
		XmlConfiguration.main(serverXml.getFile().getAbsolutePath());
	}
}
