package io;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

public class IODemo {

	public static void main(String[] args) {
		// 字节
		// ioDemo();

		// 字符
		// rwDemo();

		bfRWDemo();
	}

	public static void ioDemo() {
		InputStream is = System.in;
		try {
			int i = is.read();
			System.err.println(i);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public static void rwDemo() {
		InputStream in = System.in;
		InputStreamReader isr = new InputStreamReader(in);
		BufferedReader br = new BufferedReader(isr);
		String str;
		try {
			str = br.readLine();
			System.err.println(str);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public static void bfRWDemo() {
		InputStream in = System.in;
		InputStreamReader isr = new InputStreamReader(in);
		BufferedReader br = new BufferedReader(isr);

		String str;
		try {
			File file = new File("myfile.txt");
			file.createNewFile();
			FileWriter out = new FileWriter(file);
			// out.write("ok168");
			// out.close();
			/**
			 * 为了提高写入的效率，使用了字符流的缓冲区。 创建了一个字符写入流的缓冲区对象，并和指定要被缓冲的流对象相关联。
			 */
			BufferedWriter bout = new BufferedWriter(out);
			// 使用缓冲区中的方法将数据写入到缓冲区中。
			str = br.readLine();
			bout.write(str);
			// 使用缓冲区中的方法，将数据刷新到目的地文件中去。
			bout.flush();
			bout.close();
			System.err.println(str);
			br.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
