package socketrpc.hello;

public interface HelloRpc {
	String hello(String name);
}
