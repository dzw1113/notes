

/**
 * 
 * http://www.cnblogs.com/wangxiaoha/p/6293340.html
 * javac TargetVm.java
 * java -Xdebug -Xrunjdwp:transport=dt_shmem,address=debug,server=y,suspend=y TargetVm
 * @author dzw
 *
 */
public class TargetVm {

	public static void main(String[] args) {
		try {
			System.err.println("ssssss");
			Thread.sleep(1000000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		
	}
}
