
public class AgentRunTest {

	public static void main(String[] args) {
		AgentRunTest rt = new AgentRunTest();
		rt.test();
		try {
			Thread.sleep(10000000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}

	}

	public void test() {
		System.out.println("I'm TestAgent");
	}
}
