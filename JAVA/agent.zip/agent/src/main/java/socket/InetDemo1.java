package socket;

import java.net.InetAddress;
import java.net.UnknownHostException;

/**
 * 没有封装端口
 * 
 * @author dzw
 *
 */
public class InetDemo1 {

	public static void main(String[] args) throws UnknownHostException {
		// 使用getLoaclHost方法创建InetAddress对象
		InetAddress addr = InetAddress.getLocalHost();
		System.out.println(addr.getHostAddress());// 返回ip地址
		System.out.println(addr.getHostName());// 输入计算机名
		// 根据域名得到InetAddress对象
		addr = InetAddress.getByName("www.163.com");
		System.out.println(addr.getHostAddress());// 返回服务器的ip地址61.163.117.65
		System.out.println(addr.getHostName()); // 输出 www.163.com
		// 根据ip得到InetAddress对象
		addr = InetAddress.getByName("61.163.117.65");// 如果ip地址存在而且DNS帮你解析了，那么getHostName()这个方法返回的就是www.163.com
														// ，否则输出Ip地址
		System.out.println(addr.getHostAddress());// 返回163的服务器的ip
		System.out.println(addr.getHostName());// 输入Ip而不是域名，如果这个Ip地址不存在

	}
}
