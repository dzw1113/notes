package agent;

import java.lang.instrument.Instrumentation;

/**
 * 
 * Attach Api(com.sun.tools.attach) 运行前agent
 * 
 * @author dzw
 *
 */
public class Agent {

	public static void premain(String args, Instrumentation inst) {
		System.out.println("Hi, I'm agent!");
		inst.addTransformer(new TestTransformer());
	}

}
