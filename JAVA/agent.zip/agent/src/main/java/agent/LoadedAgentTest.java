package agent;

import java.io.IOException;

import com.sun.tools.attach.AgentInitializationException;
import com.sun.tools.attach.AgentLoadException;
import com.sun.tools.attach.AttachNotSupportedException;
import com.sun.tools.attach.VirtualMachine;

public class LoadedAgentTest {

	public static void main(String[] args) {
		VirtualMachine vm;
		try {
			vm = VirtualMachine.attach("6112");
			vm.loadAgent("E:\\canal\\agent\\target\\agent-0.0.1-SNAPSHOT.jar");
			// System.out.println(vm.getAgentProperties().get("XXX"));
			vm.detach();
		} catch (AttachNotSupportedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (AgentLoadException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (AgentInitializationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
