package agent;

import java.lang.instrument.Instrumentation;

/**
 * 运行时agent
 * 
 * @author dzw
 *
 */
public class LoadedAgent {

	@SuppressWarnings("rawtypes")
	public static void agentmain(String args, Instrumentation inst) {
		System.out.println("Hi, I'm LoadedAgent!");
		Class[] classes = inst.getAllLoadedClasses();
		for (Class cls : classes) {
			System.out.println("load Class--->" + cls.getName());
		}
		System.err.println("运行时agent执行完毕");
	}
}
