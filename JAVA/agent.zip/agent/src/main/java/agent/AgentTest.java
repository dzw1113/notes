package agent;

/**
 * add vm arg:-javaagent:E:\canal\agent\target\agent-0.0.1-SNAPSHOT.jar
 * 
 * @author dzw
 *
 */
public class AgentTest {

	public static void main(String[] args) {
		AgentTest rt = new AgentTest();
		rt.test();
		try {
			Thread.sleep(10000000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	public void test() {
		System.out.println("I'm TestAgent");
	}

}
