#生成器----生成数据的具体方式记录下来，调用的时候才生成具体的数据

#立马赋值
a = [x*2 for x in range(10)]
print(a)
#生成器第一种写法1：
a =(x*2 for x in range(10))
print(next(a))
print(next(a))
print(next(a))
print(next(a))
print(next(a))
print(next(a))
print(next(a))
print(next(a))
print(next(a))
print(next(a))

#交换a，b的值
a = 9
b = 10

#1
a,b = b,a
print(a,b)
#2
a = a+b
b = a-b
a = a-b
print(a,b)

print('--'*30)

#生成器第二种写法，带yield的都是生成器，临时保存b的值,跟return差不多，但是不是立刻返回，返回的是一个生成器
def createNum():
    a,b = 0,1
    c = 0
    for i in range(5):
        yield b
        a,b = b,a+b
        yield c
        c = a + b

nb = createNum();
print(next(nb))
print(next(nb))
print(next(nb))
print(next(nb))
print(next(nb))
print(next(nb))
print(next(nb))
print(next(nb))
print(next(nb))
print(next(nb))



print('--'*40)
def test():
    i = 0;
    while i < 5:
        temp = yield i;
        print('--',temp);
        i+=1;

t = test()
print(t.__next__())#打印i的值
print(t.send('hahah'))#把hahah的值传递给yield i，再赋值给temp,也有next作用
print(t.send('爱爱爱'))
print(t.send('擦擦擦'))
print(t.send(None))


#多任务
def t1():
    while True:
        print('---1---');
        yield None

def t2():
    while True:
        print('---2---');
        yield None

tn = t1();
tb = t2();
while True:
    tn.__next__();
    tb.__next__();


