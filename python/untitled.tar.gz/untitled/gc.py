import gc

class ClassA():
    def __init__(self):
        print(gc.garbage)
        print('object born,id:%s'%str(hex(id(self))))

#相互引用的情况下，引用计数法解决不了该情况，可以通过进程可以看到python进程不停的在增大
def f2():
    while True:
        c1 = ClassA()
        c2 = ClassA()
        c1.t = c2
        c2.t = c1
        del c1
        del c2
        gc.collect()

gc.disable()

f2()