import pexpect;
import sys;

#--------------------------linux
child = pexpect.spawn('ssh root@127.0.0.1');

child.logfile = sys.stdout;
# fout = file('mylog.txt','w')
# child.logfile = fout;
child.expect('password:');
child.sendline('Kidmadeto2016');
child.expect('root');
child.sendline('ls /');
child.expect('root');
child.sendline('exit');



