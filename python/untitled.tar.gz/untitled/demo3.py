# -- coding: utf-8 --

class Dog(object):
    def __init__(self):
        print("初始化");
    def __del__(self):
        print("销毁对象");
    def __str__(self):
        print("字符串");
    def __new__(cls, *args, **kwargs):
        print("创建对象");
        print(id(cls))
        return object.__new__(cls)

xtq = Dog();

del xtq;


#单例
class InstanceClass(object):

    __instance = None;

    def __new__(cls, *args, **kwargs):
        if cls.__instance == None:
            cls.__instance = object.__new__(cls);
            return cls.__instance;
        else:
            return cls.__instance
        #return object.__new__(cls);


isc1 = InstanceClass();
isc2 = InstanceClass();

print(id(isc1));
print(id(isc2));



#---异常以及抛出异常

class MyException(Exception):
    def __init__(self, *args, **kwargs): # real signature unknown
        print('自定义异常初始化',args)

try:
    #tx = 1/0;
    a = 1;
    b = 0;
    if b == 0:
        raise MyException('被除数不能为0')
    else:
        tx = a/b;
except(NameError) as ne:#python3写法
    print('error',ne)
except Exception as ret:
    print('通用异常',ret)
else:
    print('没有出现异常')
finally:
    print('管你有没有异常，我都执行')


