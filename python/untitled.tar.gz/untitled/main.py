#引用全部模块
# import sendmsg
# sendmsg.sendmsg()
from imp import *;
import sys;

#只引用一个方法
from sendmsg import sendsms,sendemail
#尽量少用，引用多个模块，存在相同的方法,后面的方法会覆盖前面的

#如果引用的模块sendmsg里有一个变量__all__，里面指定了方法，类的情况下，再通过from sendmsg import *的话，只能调用__all__里指定的参数
# from sendmsg import *

print(__name__)

def main():
    print('主模块')
    sendsms()
    sendemail()

#获取外部的参数
# D:\caffe\Python36\python.exe C:/Users/dzw/PycharmProjects/untitled/main.py a b c
print(sys.argv)
#会输出['C:/Users/dzw/PycharmProjects/untitled/main.py', 'a', 'b', 'c']

reload(sys)#重新加载sys模块

if __name__ ==  '__main__':
    main();

