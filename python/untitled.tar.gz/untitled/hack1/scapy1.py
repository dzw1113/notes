# -- coding: utf-8 --
from scapy.all import *
#查看网卡eno16777736，统计次数1此
dpkt  = sniff(iface = "eno16777736", count = 1)
#列出每一个字段的值
print ls(dpkt[0])
#保存到demo.pcap
wrpcap("demo.pcap", dpkt)
