from scapy.all import *

packets = rdpcap('data.pcap')
for p in packets:
    for f in p.payload.fields_desc:
        if f.name == 'src' or f.name == 'dst':
            ct = scapy.conf.color_theme
            vcol = ct.field_value
            fvalue = p.payload.getfieldval(f.name)
            reprval = f.i2repr(p.payload, fvalue)
            print "%s : %s" % (f.name, reprval)

    for f in p.payload.payload.fields_desc:
        if f.name == 'load':
            ct = scapy.conf.color_theme
            vcol = ct.field_value
            fvalue = p.payload.getfieldval(f.name)
            reprval = f.i2repr(p.payload, fvalue)
            print "%s : %s" % (f.name, reprval)