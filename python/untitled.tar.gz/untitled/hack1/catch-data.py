# -*- coding: UTF-8 -*-
try:
    import scapy.all as scapy
except ImportError:
    import scapy
try:
# This import works from the project directory
    import scapy_http.http
except ImportError:
# If you installed this package via pip, you just need to execute this
    from scapy.layers import http
packets = scapy.rdpcap('example_network_traffic.pcap')
for p in packets:
    pass;
    #print('=' * 78)
    #p.show()




import scapy_http.http as HTTP

from scapy.all import *

from scapy.error import Scapy_Exception

count = 0


def pktTCP(pkt):
    global count

    count = count + 1

    print count

    if HTTP.HTTPRequest or HTTP.HTTPResponse in pkt:

        src = pkt[IP].src

        srcport = pkt[IP].sport

        dst = pkt[IP].dst

        dstport = pkt[IP].dport

        test = pkt[TCP].payload

        if HTTP.HTTPRequest in pkt:
            print "HTTP Request:"

            print test

            print "======================================================================"

        if HTTP.HTTPResponse in pkt:

            print "HTTP Response:"

            try:

                headers, body = str(test).split("\r\n\r\n", 1)

                print headers

            except Exception, e:

                print e

            print "======================================================================"

    else:

        # print pkt[IP].src,pkt[IP].sport,'->',pkt[TCP].flags

        print 'other'


sniff(filter='tcp and port 80', prn=pktTCP, iface='eno16777736')
