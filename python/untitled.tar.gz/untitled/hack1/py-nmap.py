# -*- coding:utf-8 -*-
#python-nmap包--多进程扫描主机端口
import nmap;
import multiprocessing


class Worker(multiprocessing.Process):
    def __init__(self,*args,**kwargs):
        super(Worker, self).__init__();
        self.host = args[0];
        self.portrange = args[1];
        self.whitelist = args[2];

    def nmScan(self,host, portrange, whitelist):
        result = ''
        nm = nmap.PortScanner()
        tmp = nm.scan(host, portrange)
        result = result + "ip地址:%s \n" \
                          "主机名:[%s]  ......  %s\n" % (
            host, tmp['scan'][host]['hostnames'], tmp['scan'][host]['status']['state'])
        try:
            ports = tmp['scan'][host]['tcp'].keys()
            for port in ports:
                info = ''
                if port not in whitelist:
                    info = '非预期端口:'
                else:
                    info = '正常开放端口:'

                portinfo = "%s:%s-->state:%s--->;product:%s \n" % (
                    info, port, tmp['scan'][host]['tcp'][port]['state'], tmp['scan'][host]['tcp'][port]['product'])
                result = result + portinfo
        except KeyError:
            if whitelist:
                whitestr = ','.join(whitelist)
                result = result + "未扫到开放端口!请检查%s端口对应的服务状态" % whitestr
            else:
                result = result + "扫描结果正常，无暴漏端口"
        return result

    def run(self):
        info = self.nmScan(self.host,self.portrange,self.whitelist)
        print(info)






if __name__ == "__main__":
    hostlist = ['192.168.2.35','192.168.2.36']
    portrange = '0-8888'
    whitelist = [80, 443]

    # info = nmScan('192.168.2.35',portrange,whitelist)
    # print(info)
    jobs = []
    for host in hostlist:
        wk = Worker(host,portrange,whitelist)
        jobs.append(wk)
        wk.start()
        print(wk)
    for j in jobs:
        j.join();#阻塞当前进程，直到调用join方法的那个进程执行完，再继续执行当前进程