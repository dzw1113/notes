#http://blog.csdn.net/dreamcoding/article/details/8611578
#装饰器@方法，多个装饰器会按顺序执行
def w1(func):
    def inner():
        print('正在验证！')
        if True:
            func()
        else:
            print('没有权限')
    return inner

@w1
def f1():
    print('output-----------------f1')
def f2():
    print('output-----------------f2')

f1()
f2();

print('--'*20)

#带参数的装饰器
def mt1(func):
    def _mt1(a,b,c):
        print('正在验证！')
        if c==True:
            func(a,b,c)
        else:
            print('没有权限')
    return _mt1

@mt1
def fm1(a,b,c):
    print('output-----------------fm1')
    print(a+b)
@mt1
def fm2(a,b,c):
    print('output-----------------fm2')

fm1(1,2,True)
fm2(1,2,False);


#作用域
a = '1111' #全局

def scop():
    b = '111'#局部

print(globals())
print(locals())


class Person(object):
    __slots__ = ('name','age')
    def __init__(self, newName, newAge):
        self.name = newName
        self.age = newAge

    def eat(self):
        print("-----%s正在吃----" % self.name)


def run(self):
    print("-----%s正在跑----" % self.name)


p1 = Person("p1", 10)
p1.eat()
# p1.run = run
# p1.run()  # 虽然p1对象中 run属性已经指向了10行的函数,,,但是这句代码还不正确
# 因为run属性指向的函数 是后来添加的,几p1.run()的时候,并没有把p1当做第
# 1个参数,导致了第10行的函数调用的时候, 出现缺少参数的问题

p1.add = '上海'#slots定义了属性，不允许定义其他属性