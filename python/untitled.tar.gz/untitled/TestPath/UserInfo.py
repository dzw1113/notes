def getUserInfo():
    print('获取用户信息')