import time as tt
import sys;

tt.sleep(1)
print('sleep 3 s')

print(sys.hash_info)
