# -- coding: utf-8 --
import keyword
#关键字
print(keyword.kwlist)
print('我是个demo')

#变量,下标，类似substr
score = 100
print(score)

name ='daizhiwei'
print('------------------------------%s%s'%(name[3],len(name)))#获取第三个下标
print('------------------------------%s'%(name[1:4]))#从下标1取到下标4
print('------------------------------%s'%(name[0:-2]))#从0取到右边第二个，不包含右边第二个
print('------------------------------%s'%(name[0:-1:2]))#0:-1是从0取到最后一个，:2为步长，默认是1，调整成2是跨越
print('------------------------------%s'%(name[::-1]))
print('------------------------------%s'%(name.find("i")))
print('------------------------------%s'%(name.upper()))
#返回一个原字符串居中,并使用空格填充至长度 width 的新字符串。默认填充字符为空格
print('------------------------------%s'%(name.center(20,'*')))

变量 = 50
print(变量)

# %d整数 %s字符串
aaaa = 变量 + score
bbbb = 1
print('变量的值：%d'%aaaa)
print('变量的值：%d,%s'%(aaaa,bbbb))


#交互
#hig = input('write:\n')
#print(hig)


#常用类型转换
#http://www.cnblogs.com/to-creat/p/6439024.html
#if判断
if (810 > 50) :
    print('大于50的情况')

age0 = '18'
age1 = int(age0)
print(age0)
print(age1)

age = 10
if age>10 and age <50:
    print('大于十岁')
elif age<=10:
    print('小于十岁')
else:
    print('其他的年龄段')

x = True;#False
if True == x:
    print('true')
    print('sss')
else:
    print('ddd')

if True != x:
    print('true')
print('我是会打印出来的！因为我前面没有tab空格')


#----位于运算符
print(1+2)
print(1-2)
print(1*2)
print(12/3)
print(12//3)#商=整除数
print(12%3)#余数
print(2**2)#2的2次方-------幂
print(2**10)#2的10次方
print(2**16)#2的16次方
print('H'*20)#20个H
print('》'*20)#20个H

#----逻辑运算符and or not
if not(50>10):#就是java里的非!
    print('50不大于10')

#while循环
num = 1;
while num<10:
    num = num + 1;
    print(num)

#跳出循环
num = 1;
while num<10:
    num = num + 1;
    print(num)
    if num >5:
        break
        #continue

#嵌套
idx = 1;
if idx >= 1:
    print(idx)
    idx = idx + 10
    if idx > 10 :
        print(idx)


#复合赋值运算符，其他的算法类推
knum = 1;
knum+=2 #knum+2
knum-=1 #knum-1

knum**=2

print(knum)



snum = 1;
while snum <=5:
    print("*"*snum);
    snum+=1;



#列表------------数组
a1 = 'zhangsan'
a2 = 'lisi'
a3 = 'zhaowu'
a4 = 1
names = [a1,a2,a3,a4]
print(names)
#往最后插入
names.append('wangwu')
#往指定位子添加
names.insert(0,'sunqian')
#合并
names.extend(['maliu'])
print(names)
#从最后面删除
names.pop()#append是压栈pop是出栈
print(names)

names.remove('wangwu')
print(names)
del names[0]
print(names)

if 'lisi' in names:
    print('有 lisi')

#空执行
if 'lisi' in names:
    pass


#字典---------{键：值}，就是js里的对象
info = {"name":"张三","add":"上海","age":18}
print(info["name"])

info["name"] = '李四'
print(info["name"])
print(info.get("name"))

del info["name"]
print(info)
print('#'*10)
print(info.keys())
print(info.values())
print(info.items())

for vl in info.values():
    print(vl)

#for循环以及for else
idxs = [11,22,33,44,55];
print(len(idxs))
for ix in idxs :
    print(ix)
    break#有这个的时候不会输出else
else:
    print('#'*5)


#元组，元组和列表没区别，唯一区别不能修改
tp = (11,22,33)
print(type(tp))

print(tp)
for ix in tp:
    print(ix)


#定义函数

def method1(str,str1):
    print("打印%s,%s"%(str,str1))

print("打印222")
method1(333,444)


def header():
    print(1)
    body()
    foot()

def body():
    print(2)

def foot():
    print(3)

header()

#带返回值的函数
def retMethod(a,b):
    c = a+b;
    print('a+b')
    return c
    return c+1

c = retMethod(2,2);
print(c)

print(retMethod(2,2))
print(retMethod(2,2))

def retMethod():
    return [11,22]

print(retMethod())



#局部变量
def mt1():
    aa = 1
    print(aa)


def mt2():
    aa = 2
    print(aa)

mt1()
mt2()

#print(aa) 会报错


def df_mt(a,b=2):
    print(a+b)

df_mt(1)

def df_mt1(a,b=2,c=3):
    print(a+b+c)

df_mt1(1,3)
df_mt1(1,c=3)


#不定长参数
def long_mth(*args):
    print(args)

long_mth(11,22,33,44)

def long_mth1(*args,**abs):
    print(args)
    print(abs)
#两个**代表有名字的,一个是没有名字的
long_mth1(55,abs=11,aa=22)


#对象的内存地址
a_id = 101
b_id = 100
print(id(a_id))
print(id(b_id))


#列表和字典是可变，字符串、元组和数字是不可变的

#匿名函数
niming_meth = lambda num1,num2:(num1+num2)
print(niming_meth(1,2))


nb = [11,33,22]
nb.sort()
print(nb)

#指定key排序
infos = [{"name":"abc","age":18},{"name":"def","age":17}]
infos.sort(key=lambda x:x['age'])
print(infos)


def test(a,b,func):
    result = func(a,b)
    print(result)

#python2可以把lambda a,b:a-b直接以input输入进去，python不行，需要eval转换
test(22,22,lambda a,b:a-b)
