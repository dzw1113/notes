# -- coding: utf-8 --
# 多进程
import multiprocessing
import time;


def worker(num):
    """thread worker function"""
    print('我是进程:', num, '进程名字为：', multiprocessing.current_process().name);
    time.sleep(5);  # 便于通过查看进程
    return


def daemon():
    name = multiprocessing.current_process().name
    print('Starting:', name)
    time.sleep(2)
    print('Exiting :', name)


def non_daemon():
    name = multiprocessing.current_process().name
    print('Starting:', name)
    print('Exiting :', name)


if __name__ == '__main__':
    jobs = []
    for i in range(5):
        p = multiprocessing.Process(target=worker, args=(i,), name=(('process%s' % (i)),))
        jobs.append(p)
        p.start();

    #守护进程
    d = multiprocessing.Process(name='daemon',
                                target=daemon)
    d.daemon = True
    n = multiprocessing.Process(name='non-daemon',
                                target=non_daemon)
    n.daemon = False
    d.start()
    n.start()
    d.join(1)#阻塞当前进程，直到调用join方法的那个进程执行完，再继续执行当前进程
    print('d.is_alive()', d.is_alive())
    n.join()#阻塞当前进程，直到调用join方法的那个进程执行完，再继续执行当前进程