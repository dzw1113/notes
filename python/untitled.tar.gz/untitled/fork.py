import os;
import time;

ret = os.fork()#windows 没有该方法
if ret == 0 :
    while True:
        print('----1---');
        time.sleep(1);
else:
    while True:
        print('----2---');
        time.sleep(1);

# import os;
# import time;
#
# ret = os.fork()
# print(ret);
# print('hahah')
# if ret>0:
#     print('father',os.getpid())
# else:
#     print('childs',os.getpid(),'---',os.getppid())