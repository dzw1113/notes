from collections import Iterable;

abs = 'abs'

#判断是否可迭代,比之前的for占的内存少
print(isinstance(abs,str))
print(isinstance(abs,Iterable))

b = iter(abs)
print(next(b))
print(next(b))
print(next(b))

print('-'*100)
#闭包
def test(number):
    print('---1---')

    def test_in(number1):
        print('---2---')
        print(number+number1)
    print('---3---')
    return test_in
#把test(100)执行一个变量
tt = test(100)
#调用tt=test_in方法，就是闭包
tt(1)
tt(100)


def line_conf(a,b):
    def line(x):
        return a*x+b
    return line

print('*'*100)
line1 = line_conf(3,3)
line2 = line_conf(5,5)
print(line1(5))
print(line2(5))