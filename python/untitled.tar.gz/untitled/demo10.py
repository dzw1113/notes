a = [11,22,33,54,552,12,45,22,11,33,21];

b = set(a);
c = list(a)
print(b)
print(c)

#取字符串的交集
m = 'abcd'
k = set(m)
print(k)
n = 'cd'
l = set(n)
print(k&l)