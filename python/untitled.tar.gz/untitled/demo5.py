import copy

a = [11,22,33]
b = [11,22,33]
c = a
i = 10
k = 10

print('a==1',a==1)
print('a is b',a is b)
print('a is c',a is c)
print('i==k' ,i==k)
print('i is k',i is k)

c = copy.copy(a)
print('a is c',a is c)
c = copy.deepcopy(a)
print('a is c',a is c);


class TestCs(object):
    def __init__(self):
        self.__num = 100

    def get_num(self):
        return self.__num;

    def set_num(self,nm):
        self.__num = nm;

    num = property(get_num,set_num)

ts = TestCs();
ts.num = 50#相当于set_num
print(ts.num)#相当于调用了get_num