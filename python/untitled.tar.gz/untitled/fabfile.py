# -- coding: utf-8 --

from fabric.api import *
from fabric.colors import *


def host_type():
    run('uname -s')

env.hosts=['ip','ip']
env.user='root'
env.port='22'
env.password='密码'


@runs_once  #所有的主机只会执行一次
def input_raw():
    return prompt(yellow("请输入目录"),default='/mnt');

def workask(dirname):
    run('ls -l '+ dirname);

@task
def go():
    print(env)
    print('开始--------------->')
    getdirname = input_raw();
    workask(getdirname)
    print('结束--------------->')

@runs_once
def writeile():
    run('echo \'11\'>a.txt');
    with lcd('/root'):
        local('tar zcvf a.tar.gz a.txt')

@task
def putFile():
    writeile()
    with cd('/root'):
        put('/root/a.tar.gz','/mnt/a.tar.gz')