__all__ = ['sendsms']
def sendmsg():
    print('发送消息')

def sendsms():
    print('发送短信')

def sendemail():
    print('发送邮件')

#自己执行的时候，就是个__name__字符串，如果别人调用的情况，就是当前模块名
print(__name__)