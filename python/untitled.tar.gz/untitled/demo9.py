class Test(object):
    def __call__(self, *args, **kwargs):
        print('------我被调用了-------')
p = Test();
p();#类似于直接调用call



class Person(object):
    def __init__(self,func):
        print('初始化');
        print('function name is ',func.__name__)
        self.__func = func;
    def __call__(self, *args, **kwargs):
        print('------call-------')
        self.__func()


@Person
def test():
    print('test')

test();


#元类
class Demo():
    num = 1;
    print('===========object===========');

    def test(self):
        print('-------test-----------')

print(Demo)

#动态创建类,元类=用来创建class的=type,type方法有两个功能，1、识别类型2、创建类，在python中是一个方法有两种功能是不提倡的。
class Tst:
    pass;

t = Tst();

def printNum():
    print('print num')

t1 = type('Tst1',(),{"printNum":printNum,"num":10})
t1.printNum()
print(t1.num)

print('----================-----分界线');

class Animal:
    def eat(self):
        print('----吃东西-----');

class Cat(Animal):
    pass;


def eat():
    print('-----吃狗粮--------')

Dog = type("Dog",(Animal,),{})
dog = Dog();
print(dog.eat)
dog.eat();
print(dog.__class__.__class__);

print('----================-----分界线');


def upper_attr(future_class_name, future_class_parents, future_class_attr):

    #遍历属性字典，把不是__开头的属性名字变为大写
    newAttr = {}
    for name,value in future_class_attr.items():
        if not name.startswith("__"):
            newAttr[name.upper()] = value

    #调用type来创建一个类
    return type(future_class_name, future_class_parents, newAttr)

class Foo(object):
    __metaclass__ = upper_attr #设置Foo类的元类为upper_attr
    bar = 'bip'

print(hasattr(Foo, 'bar'))
print(hasattr(Foo, 'BAR'))

t = Foo()
print(dir(Foo))
print(dir(__builtins__))
# print(t.BAR)
# print(t.bar)

'''
一个python文件相当于一个模块，模块都有内置的属性信息，用 dir(模块名) 可以查看：
     __doc__ ： 模块的docstring
     __file__ ：模块文件在磁盘上的绝对路径
     __name__ ：模块的名称（独立运行时值是__main__，被import时值是模块的名称）
    __main__ :：执行的主module的名字
    __bases__：用于类声明中的基类对象元组；
    __module__ ：定义类的模块名
'''