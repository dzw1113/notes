from fabric.api import *

#上传文件并执行，部署自己写代码

env.hosts=['ip','ip']
env.user='root'
env.port='22'
env.password='密码'

@task
@runs_once
def tar_task():
    with lcd('/home/itcast/testdemo'):
        local('tar zcvf demo.tar.gz demo.py')

@task
def put_task():
    run('mkdir -p /home/itcast/testdemo')
    with cd('/home/itcast/testdemo'):
        put('/home/itcast/testdemo/demo.tar.gz', '/home/itcast/testdemo/demo.tar.gz')

@task
def check_task():
    lmd5 = local('md5sum /home/itcast/testdemo/demo.tar.gz', capture=True).split(' ')[0]
    rmd5 = run('md5sum /home/itcast/testdemo/demo.tar.gz').split(' ')[0]
    if lmd5 == rmd5:
        print('OK ...')
    else:
        print('ERROR ...')

@task
def run_task():
    with cd('/home/itcast/testdemo'):
        run('tar zxvf demo.tar.gz')
        run('python demo.py')

@task
def go():
    tar_task()
    put_task()
    check_task()
    run_task()