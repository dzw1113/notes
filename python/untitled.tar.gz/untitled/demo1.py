import os;
import sys;

def writeFile():
    # w+后面的有+，则是有则覆盖，没有则创建
    doc = open("d:\\aaa.txt", "w+");
    print("文件名: ", doc.name);
    doc.write("写文件的demo案例\n哈哈哈");
    # 返回文件当前位置
    doc.tell()
    # 设置文件当前位置
    doc.seek(os.SEEK_SET);
    ctx = doc.read();
    print(ctx)
    doc.close()


class Person:
    def __init__(self):
        self.add = '上海'
        self.__ser = "私有密码"
        print('初始化')

    def eat(self,name):
        print(name,"在吃苹果")
    def write(self):
        print(self.add,"写作业")
        print("私有的属性",self.__ser)
    def __ml(self):#两个下划线是私有方法
        print("我是一个私有方法")
    def __del__(self):
        print("我被销毁了")

#创建对象，会调用初始化
person = Person();
person.write();

person.name = '张三'
person.age = 18

print(person.name)
person.eat(person.name)
print(person.add)

print('我被引用了：',sys.getrefcount(person))

del person;

class BlackPerson(Person):
    def __init__(self):
        print('我是黑人！')

    def mt(self):
        print("黑人自己的方法1")

class WhitePerson(Person):
    def __init__(self):
        print('我是白人！')

    def mt(self):
        print("白人自己的方法2")

blPerson = BlackPerson();
blPerson.eat('tom')
del blPerson;


class NonPerson(BlackPerson,WhitePerson):
    #类属性
    num = 0;
    #实例方法
    def __init__(self):
        print('我是黑白杂交的！')
        NonPerson.num=NonPerson.num+1;
        #实例属性
        vl = 0;

    #类方法
    @classmethod
    def class_meth(cls):
        #可以直接操作类属性，不需要带类名
        cls.num = 5;
        print("我是一个类方法")

    #静态方法
    @staticmethod
    def static_meth():
        print("我是一个静态方法")

ps = NonPerson();
ps.eat("黑白人")
ps.mt();
#最后会调用黑人的方法是因为下面的mro---C3算法
print(NonPerson.__mro__)
#创建一次num就+1
ps1 = NonPerson();
print(NonPerson.num)
ps.class_meth()

print(NonPerson.num)

NonPerson.static_meth()

del ps;
del ps1;