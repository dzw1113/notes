# -- coding: utf-8 --
#派生类---子类
import multiprocessing

class Worker(multiprocessing.Process):

    def run(self):
        print('In %s' % self.name)
        return

if __name__ == '__main__':
    jobs = []
    for i in range(5):
        p = Worker()
        jobs.append(p)
        p.start()
    for j in jobs:
        j.join();#阻塞当前进程，直到调用join方法的那个进程执行完，再继续执行当前进程