import TestPath.UserInfo as ui
#from TestPath.UserInfo import getUserInfo


#调用包TestPath下面的UserInfo模块，执行获取用户方法
ui.getUserInfo()
print('aaaaa')
